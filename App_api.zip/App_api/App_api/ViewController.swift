//
//  ViewController.swift
//  App_api
//
//  Created by Ana Carolina Alves Ramos  on 13/08/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var txtcep: UITextField!
    @IBOutlet weak var lblLog: UILabel!
    @IBOutlet weak var lblLocal: UILabel!
    @IBOutlet weak var lblddd: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func btnPesquisar(_ sender: Any) {
        ApiViaCep.pesquisarCEP(txtcep.text!) { (cep) in
            DispatchQueue.main.async {
                self.lblLog.text = "Logradouro: \(cep.logradouro)"
                self.lblLocal.text = "Localidade/UF: \(cep.localidade)/\(cep.uf)"
                self.lblddd.text = "DDD: \(cep.ddd)"
            }
            
        }
    }
    
}

