import UIKit

class DetailsViewController: UIViewController {

    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblemail: UILabel!
    @IBOutlet weak var lblAdress: UILabel!
    @IBOutlet weak var lblnumber: UILabel!
    
    var contact: Contato? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let item = contact {
            self.navigationItem.title = item.number
            lblemail.text = item.email
            lblnumber.text = item.number
            lblName.text = item.name
            lblAdress.text = item.adress
        }

        
    }


}
