struct Contato{
    var name: String
    var number: String
    var email: String
    var adress: String
}
