import UIKit

class Home: UIViewController {
    
    @IBAction func NovoContato(_ sender: Any) {
        let novoContatoVC = NovoContatoViewController(nibName: "NovoContatoViewController", bundle: nil)
        novoContatoVC.delegate = self
        self.navigationController?.pushViewController(novoContatoVC, animated: true)
        
    }
    
    
    @IBOutlet weak var tabela: UITableView!
    var list: [Contato] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        LoadList()
        tabela.dataSource = self
        tabela.delegate = self
        self.navigationItem.title = "Home"
    }
    
    private func LoadList(){
        let item1 = Contato(name: "Ana", number: "19999-9999", email: "ana@gmail.com", adress: "Rua Itaipu")
        let item2 = Contato(name: "Joao", number: "29999-9999", email: "joao@gmail.com", adress: "Rua Itaipu")
        let item3 = Contato(name: "Manu", number: "39999-9999", email: "manu@gmail.com", adress: "Rua Itaipu")
        let item4 = Contato(name: "Misha", number: "49999-9999", email: "misha@gmail.com", adress: "Rua Itaipu")
        let item5 = Contato(name: "Lior", number: "59999-9999", email: "lior@gmail.com", adress: "Rua Itaipu")
        
        
        list.append(item1)
        list.append(item2)
        list.append(item3)
        list.append(item4)
        list.append(item5)
        
    }
    
}

extension Home: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "CostumCell") as? ContactCell else{
            return UITableViewCell()
        }
        let item = list[indexPath.row]
        cell.populate(contact: item)
        return cell 
    }
}


extension Home: UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 110.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let contact = list[indexPath.row]
        let vc = DetailsViewController()
        vc.contact = contact
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}

extension Home: NovoContatoViewControllerDelegate{
    func salvarNovoContato(contato: Contato){
        list.append(contato)
        tabela.reloadData()
    }
}
