import UIKit

protocol NovoContatoViewControllerDelegate{
    func salvarNovoContato(contato: Contato)
}

class NovoContatoViewController: UIViewController {
    
    public var delegate: NovoContatoViewControllerDelegate?

    @IBOutlet weak var TxtName: UITextField!
    @IBOutlet weak var TxtNumber: UITextField!
    @IBOutlet weak var TxtEmail: UITextField!
    @IBOutlet weak var TxtAdress: UITextField!
    
    
    @IBAction func salvarcontato(_ sender: Any) {
        let contato = Contato(name: TxtName.text ?? "",
                              number: TxtNumber.text ?? "",
                              email: TxtEmail.text ?? "",
                              adress: TxtAdress.text ?? "")
        delegate?.salvarNovoContato(contato: contato)
        navigationController?.popViewController(animated: true)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Novo Contato"
        

        
    }

    

}
