struct Contato: Codable{
    let name: String
    let number: String
    let email: String
    let adress: String
}

// Encodable transforma um dado em Json. 
