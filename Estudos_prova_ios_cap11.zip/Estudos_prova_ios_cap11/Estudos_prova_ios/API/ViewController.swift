
import UIKit

class ViewController: UIViewController {
    private var isBusy: Bool = false

    @IBOutlet weak var txtresult: UITextView!
    @IBOutlet weak var txtcep: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

    @IBAction func searchTapped(_ sender: Any) {
        if isBusy{
            return
        }
        self.isBusy = true
        self.txtresult.text = ""
        guard let cep = txtcep.text,
              !cep.isEmpty && cep.count == 8 else{return}
        if let url = URL(string: "https://viacep.com.br/ws/\(cep)/json/"){
            let urlSession = URLSession.shared
            urlSession.dataTask(with: url) { [weak self] data, response, error in
                guard let self = self else { return }
                if let resultData = data{
                    do {
                        let localStruct = try JSONDecoder().decode(CepResponseData.self, from: resultData)
                        DispatchQueue.main.async {
                            self.txtresult.text = String(describing: localStruct)
                        }
                    } catch {
                        print("==> Erro no parser da struct")
                    }
                }
                if let resultError = error{
                    print("==> Erro na requisicao: \(resultError)")
                }
                self.isBusy = false
            }.resume()
        }
    }
    
}
