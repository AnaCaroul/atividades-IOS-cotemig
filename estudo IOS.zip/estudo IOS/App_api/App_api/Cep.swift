//
//  Cep.swift
//  App_api
//
//  Created by Ana Carolina Alves Ramos  on 13/08/23.
//

import Foundation

struct Cep: Codable{
    var logradouro: String
    var localidade: String
    var uf: String
    var ddd: String
}
