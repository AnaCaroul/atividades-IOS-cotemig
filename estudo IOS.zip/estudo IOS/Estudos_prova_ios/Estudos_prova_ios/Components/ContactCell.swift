import UIKit

class ContactCell: UITableViewCell {
    
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblNumber: UILabel!
    @IBOutlet weak var lblAdress: UILabel!
    
    
    func populate(contact: Contato){
        lblName.text = contact.name
        lblEmail.text = contact.email
        lblAdress.text = contact.adress
        lblNumber.text = contact.number
    }
    
    
}
