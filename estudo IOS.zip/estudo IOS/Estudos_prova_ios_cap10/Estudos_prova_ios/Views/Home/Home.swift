import UIKit

class Home: UIViewController {
    
    var userDefaults = UserDefaults.standard
    let listaDecontatosKey = "ListaDeContatos"
    // a chave é o que iremos usar para recuperar ou atualizar o valor desse dado.
    
    @IBAction func NovoContato(_ sender: Any) {
        let novoContatoVC = NovoContatoViewController(nibName: "NovoContatoViewController", bundle: nil)
        novoContatoVC.delegate = self
        self.navigationController?.pushViewController(novoContatoVC, animated: true)
        
    }
    
    @IBOutlet weak var tabela: UITableView!
    var list: [Contato] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tabela.dataSource = self
        tabela.delegate = self
        self.navigationItem.title = "Home"
        
        
        let listaData = userDefaults.value(forKey: listaDecontatosKey) as! Data
        do {
            let listaContatos = try JSONDecoder().decode([Contato].self, from: listaData)
            list = listaContatos
            tabela.reloadData()
        } catch {
            print("Erro em converter os dados: \(error.localizedDescription)")
        }
    }
    
    
}

extension Home: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "CostumCell") as? ContactCell else{
            return UITableViewCell()
        }
        let item = list[indexPath.row]
        cell.populate(contact: item)
        return cell 
    }
}

extension Home: UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 110.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let contact = list[indexPath.row]
        let vc = DetailsViewController()
        vc.contact = contact
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}

extension Home: NovoContatoViewControllerDelegate{
    func salvarNovoContato(contato: Contato){
        list.append(contato)
        tabela.reloadData()
        do {
            let dataLista = try JSONEncoder().encode(list)
            userDefaults.setValue(dataLista, forKey: listaDecontatosKey)
        } catch {
            print("Erro ao salvar dados na memória local: \(error.localizedDescription)")
        }
    }
}
